// api/index.php
<?php

require __DIR__ . '/../public/index.php';